#include <iostream>
#include <string>
#include <cstdlib>
#include "./facts.h"
using namespace std;

int main(int argc, char *argv[]){
	int check_arg = 0, state_num;
	string filename, state_nums;
	bool restart = true;
	do{
		if(check_arg == 0){
			if(!is_valid_arguments(argv, argc)){
				cout << "usage: exe -s # -f filename" << endl;
				return 0;
			}else{
				state_nums = argv[2];
				filename = argv[4];
				if(!check_num(state_nums)){
					state_num = get_num();
				}else{
					state_num = atoi(state_nums.c_str());
				}
				if(!check_file(filename)){
					filename = get_file();
				}
			}
		}
		if(check_arg != 0){
			state_num = get_num();
			filename = get_file();
		}
		check_arg++;
		cout << endl;
		get_info(state_num, filename);
		restart_prompt(restart);
	}while(restart == true);
}